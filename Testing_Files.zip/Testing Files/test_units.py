import unittest
import units

# for create table function
class createtabletest(unittest.TestCase):
    def test_exist_table(self):
        self.assertEqual(units.create_table('True'), "DataExist!") # The table already exists
    def test_notexist_table(self):
        self.assertEqual(units.create_table('False'), "DatasetCompleted!") # The table does not exist previously

#for insert table function
class inserttabletest(unittest.TestCase):
    def test_notexist_db(self):
        self.assertEqual(units.insert_table('NoDatabase'), "Not Exist!") # The table does not exist
    def test_exist_data(self):
        self.assertEqual(units.insert_table('DataInserted'), "DataAlreadyExist!") # The table already has data
    def test_notexist_data(self):
        self.assertEqual(units.insert_table('NotInserted'), "DataInserted!") # The table exists but don't have data

#to open main window function
class mainwindowtest(unittest.TestCase):
    def test_exist_window(self):
        self.assertEqual(units.main('True'), ["Close", "Show"]) # A previous window is opened
    def test_notexist_window(self):
        self.assertEqual(units.main(None), ["Show"]) # No previous windows opened

#to fetch initial data for table function
class initialdatatimetest(unittest.TestCase):
    def test_exist_window(self):
        self.assertGreater(units.initialdatatime(), 0) # Data is fetched ("Fetched") or not ("Failed")

#search function for insepction details (time), violation distribution and animal related cases features
class search1test(unittest.TestCase):
    def test_correct_search(self):
        self.assertGreater(units.search1("01/02/2012", "01/02/2013"), 0) # Correct date format
    def test_wrongformat_search(self):
        self.assertEqual(units.search1("01022012", "01022013"), "Not Found: Please enter right date format") # Wrong date format, this message should be wx.MessageBox
    def test_letters_search(self):
        self.assertEqual(units.search1("AA/BB/CCCC", "DD/EE/FFFF"), "Not Found: Please enter value within date range / incorrect date") # Type in letters
    def test_outofrange_search(self):
        self.assertEqual(units.search1("01/01/1800", "01/01/1810"), "Not Found: Please enter value within date range / incorrect date") # Type in out of range date

#serach function for violation keyword feature
class search2test(unittest.TestCase):
    def test_correct_search(self):
        self.assertGreater(units.search2("Cold", "01/02/2015", "01/02/2017"), 0) # Correct date format
    def test_wrongformat_search(self):
        self.assertEqual(units.search2("Cold", "01022015", "01022017"), "Not Found: Please enter a keyword / right date format") # Wrong date format, this message should be wx.MessageBox
    def test_letters_search(self):
        self.assertEqual(units.search2("Cold", "AA/BB/CCCC", "DD/EE/FFFF"), "Not Found: Keyword is not found in date range / Date out of range / Incorrect Date") # Type in letters, this message should be wx.MessageBox
    def test_outofrange_search(self):
        self.assertEqual(units.search2("Cold", "01/01/1800", "01/01/1810"), "Not Found: Keyword is not found in date range / Date out of range / Incorrect Date") # Date out of range, this message should be wx.MessageBox
    def test_nokeyword_search(self):
        self.assertEqual(units.search2("", "01/02/2012", "01/02/2013"), "Not Found: Please enter a keyword / right date format")  # No keyword, this message should be wx.MessageBox
    def test_notindate_search(self):
        self.assertEqual(units.search2("Cold", "01/02/2012", "01/02/2013"), "Not Found: Keyword is not found in date range / Date out of range / Incorrect Date")  # Keyword not found in date range, this message should be wx.MessageBox

#search function for inspection details (borough) feature
class search3test(unittest.TestCase):
    def test_correct_search(self):
        self.assertGreater(units.search3("QUEENS"), 0) # Correct search
    # no more tests because search option is from pre-determined selection

#display individual feature windows function
class displayrequirementtest(unittest.TestCase):
    def test_window(self):
        self.assertEqual(units.displayrequirement(), ["Close", "Show"]) # Open feature window