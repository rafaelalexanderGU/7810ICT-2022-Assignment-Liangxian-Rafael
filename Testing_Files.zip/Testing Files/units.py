import sqlite3
import pandas as pd

def create_table(file):
    # connect with dataset
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    if file == 'False':
        try:
            with open('drop_table.sql', 'r') as f:
                sql = f.read()
            # execute
            cur.execute(sql)
        except:
            pass
    elif file == 'True':
        try:
            # sql read
            with open('create_table.sql', 'r') as f:
                sql = f.read()
            # execute
            cur.execute(sql)
        except:
            pass
    try:
        # sql read
        with open('create_table.sql', 'r') as f:
            sql = f.read()
        # execute
        cur.execute(sql)
        result = 'DatasetCompleted!'
        return result
    except:
        result = 'DataExist!'
        return result

def insert_table(file):
    # connect with dataset
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    if file == 'NoDatabase':
        with open('drop_table.sql', 'r') as f:
            sql = f.read()
        # execute
        cur.execute(sql)
    elif file == 'DataInserted':
        data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
        data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)
    elif file == 'NotInserted':
        with open('delete_table_data.sql', 'r') as f:
            sql = f.read()
        # execute
        cur.execute(sql)
    try:
        # query
        sql = 'select * from NYC_Restaurant_Inspections'
        cur.execute(sql)
        # results
        res = cur.fetchall()
        if len(res) > 0:
            result = 'DataAlreadyExist!'
            return result
        else:
            data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
            data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)
            result = 'DataInserted!'
            return result
    except:
        result = 'Not Exist!'
        return result

def initialdatatime():
    # connect with dataset
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    # read
    data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
    data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)
    # initial data
    sql = "select * from NYC_Restaurant_Inspections limit 20"
    cur.execute(sql)
    data = cur.fetchall()
    fetchedData = len(data)
    return fetchedData


def search1(date1, date2):
    # db initialize for test
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    # read
    data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
    data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)

    # CODE
    if len(date1) == 10 and len(date2) == 10 and len(
            date1.replace('/', '')) == 8 and len(date2.replace('/', '')) == 8:
        global start, end
        start = date1.split('/')[2] + date1.split('/')[0] + \
                date1.split('/')[1]
        end = date2.split('/')[2] + date2.split('/')[0] + \
              date2.split('/')[1]
        sql = "select * from NYC_Restaurant_Inspections where substr(INSPECTION_DATE,7,4) || substr(INSPECTION_DATE,1,2) || substr(INSPECTION_DATE,4,2) between '{}' and '{}'".format(
            start, end)
        cur.execute(sql)
        data = cur.fetchall()
        if len(data) == 0:
            message = "Not Found: Please enter value within date range / incorrect date"
            return message
        else:
            fetchedData = len(data)
            return fetchedData
    else:
        message = "Not Found: Please enter right date format"
        return message

def search2(keyword, date1, date2):
    # db initialize for test
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    # read
    data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
    data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)

    # this loop indicate input validation
    if len(keyword) > 0 and len(date1) == 10 and len(date2) == 10 and len(
            date1.replace('/', '')) == 8 and len(date2.replace('/', '')) == 8:
        global start, end
        start = date1.split('/')[2] + date1.split('/')[0] + \
                date1.split('/')[1]
        end = date2.split('/')[2] + date2.split('/')[0] + \
              date2.split('/')[1]
        sql = "select * from NYC_Restaurant_Inspections where substr(INSPECTION_DATE,7,4) || substr(INSPECTION_DATE,1,2) || substr(INSPECTION_DATE,4,2) between '{}' and '{}' and VIOLATION_DESCRIPTION like '%{}%'".format(
            start, end, keyword)
        cur.execute(sql)
        data = cur.fetchall()
        if len(data) == 0:
            message = "Not Found: Keyword is not found in date range / Date out of range / Incorrect Date"
            return message
        else:
            fetchedData = len(data)
            return fetchedData
    else:
        message = "Not Found: Please enter a keyword / right date format"
        return message

def search3(borough):
    # db initialize for test
    con = sqlite3.connect('NYC_Restaurant.db')
    # cursor
    cur = con.cursor()
    # read
    data = pd.read_csv('DOHMH_New_York_City_Restaurant_Inspection_Results.csv')
    data.to_sql('NYC_Restaurant_Inspections', con=con, if_exists='replace', index=False)

    # sql query
    sql = "select * from NYC_Restaurant_Inspections where BORO = '{}'".format(borough)
    cur.execute(sql)
    data = cur.fetchall()
    fetchedData = len(data)
    return fetchedData

# display main window
def main(mainWindow):
    # whether close window or not
    window = []
    if mainWindow == None:
        pass
    elif mainWindow == "True":
        # mainWindow.Close()
        window.append("Close")

    # GUI CODE IS HERE, not applicable for test

    # window.Show()
    window.append("Show")
    return window

def displayrequirement():
    window = []

    # mainWindow.Close() this closes previous window
    window.append("Close") #this is for test purposes

    # GUI CODE IS HERE, not applicable for test

    # window.Show()
    window.append("Show") #this is for test purposes
    return window
